<?php 
define('SKYLIGHT',dirname(__FILE__));
require_once('classes/safemysql.php');
require_once('config.php');
$cmnt="none";
$sign_hash ='';
$transaction=$_POST['m_operation_id'];

$ta=$db->getOne("SELECT transaction FROM deposits WHERE transaction=?i", $transaction);
if ($ta==$transaction){exit;}

$sum=$_POST['m_amount']; 
$id=$_POST['m_orderid'];

	
if (isset($_POST['m_operation_id']) && isset($_POST['m_sign']))
{
	$arHash = array($_POST['m_operation_id'],
			$_POST['m_operation_ps'],
			$_POST['m_operation_date'],
			$_POST['m_operation_pay_date'],
			$_POST['m_shop'],
			$_POST['m_orderid'],
			$_POST['m_amount'],
			$_POST['m_curr'],
			$_POST['m_desc'],
			$_POST['m_status'],
			$m_key);
	$sign_hash = strtoupper(hash('sha256', implode(':', $arHash)));
if ($_POST['m_sign'] == $sign_hash && $_POST['m_status'] == 'success')
{
	echo $_POST['m_orderid'].'|success';
	
		
$referer=$db->getOne("SELECT curator FROM `ss_users` WHERE id=?i", $id);

$db->query("INSERT INTO deposits (userid, curatorid, summa, unixtime,transaction) VALUES(?i,?i,?s,?s,?s)", $id, $referer, $sum, time(), $transaction);	

$time_in=time();
$speed=$db->getOne("SELECT speed FROM `ss_users` WHERE id=?s", $id);
$updat=$db->getOne("SELECT updat FROM `ss_users` WHERE id=?s", $id);
$with_sum=($time_in-$updat)*$speed;
	$n_speed=$sum*$cf;
	$db->query("UPDATE ss_users SET refill=refill+$sum WHERE id=?i",$id);
	$db->query("UPDATE ss_users SET updat=$time_in WHERE id=?i",$id);
	$db->query("UPDATE ss_users SET speed=speed+$n_speed WHERE id=?i",$id);
    addpay($id, "Оплата мощности автомобиля", $sum);

if($with_sum>0.99){
	require_once('pay_user.php');
}else{
	$speed2=$db->getOne("SELECT speed FROM `ss_users` WHERE id=?s", $id);
	$speed_kor=$with_sum/$speed2;
	$time_kor=intval($speed_kor);
	
	
	$db->query("UPDATE ss_users SET updat=updat-$time_kor WHERE id=?i",$id);
}


$adminid=$db->getOne("SELECT id FROM `ss_users` WHERE wallet=?s", $koshelek_admina);
$adminsum=$sum*($admpercent/100);
$db->query("UPDATE config SET admin_per=admin_per+$adminsum WHERE id=?i",1);
require_once('pay_admin.php');
	


$refererwallet=strtoupper($db->getOne("SELECT wallet FROM `ss_users` WHERE id=?i", $referer));
$referersum=$sum*($refpercent/100);
if($referer>0 && $refererwallet[0]=='P'){
$db->query("UPDATE ss_users SET refs_wait=refs_wait+$referersum WHERE id=?i",$referer);
$db->query("UPDATE ss_users SET curator_pay=curator_pay+$referersum WHERE id=?i",$id);
addpay($referer, "Партнерское вознаграждение", $referersum);		
}
$refs_pays=$db->getRow("SELECT * FROM ss_users WHERE refs_wait>?s ORDER BY id ASC LIMIT 1",$min_payeer);

if($refs_pays['id']>0){


$wallet=$db->getOne("SELECT wallet FROM ss_users WHERE id=?i", $refs_pays['id']);		
$refs_id=$refs_pays['id'];	

require_once('pay_ref.php');

}
exit;
}
echo $_POST['m_orderid'].'|error';

}
?>