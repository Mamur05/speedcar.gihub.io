<?
if(file_exists(dirname(__FILE__)."/core/ini.php")){
define ("SKYLIGHT" , dirname(__FILE__) );
$_SERVER['DOCUMENT_ROOT']=dirname(__FILE__);}
else if(file_exists($_SERVER['DOCUMENT_ROOT']."/core/ini.php") && !empty($_SERVER['DOCUMENT_ROOT'])){define ("SKYLIGHT" , $_SERVER['DOCUMENT_ROOT']);
}else{
	die ("NOT_DEFINED_ROOT_DIR");
}
define ("CRON" , 1);
error_reporting(0); // вывод ошибок
if(empty($nocron)){
require_once('ini.php');
$nocron=1;
}



if($nocron==1) 
{






}

?>