<?php 
if(!defined('SUCCESSPAY')){
echo ('Выявлена попытка взлома!');
exit();
}



?>
