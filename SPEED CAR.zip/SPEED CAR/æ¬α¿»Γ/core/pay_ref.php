<?
if(!defined('SKYLIGHT')){
exit();
}
$refs_per=$db->getOne("SELECT refs_wait FROM `ss_users` WHERE id=?i", $refs_id);

if($refs_per>$min_payeer){
	
		require_once('classes/cpayeer.php');	
		$payeer = new CPayeer($accountNumber, $apiId, $apiKey);
		if ($payeer->isAuth()){
			$arBalance = $payeer->getBalance();
		}
		$balance = $arBalance["balance"]["RUB"]["DOSTUPNO"];

		if($refs_per<$balance){
			
			
		
	    $m_curr='RUB'; 
		$com='Эй, водила! Ты глянька тебе пришло партнерское вознаграждение с проекта SPEED CAR';
		$arTransfer = $payeer->transfer(array(
		'curIn' => $m_curr,
		'sum' => $refs_per,
		'curOut' => $m_curr,
		'to' => $wallet,
		'comment' => $com,
		'anonim' => 'Y', // анонимный перевод
	));
	if (!empty($arTransfer['historyId']) && $arTransfer['historyId']>0)
	{
		$db->query("UPDATE ss_users SET refs_wait=refs_wait-$refs_per WHERE id=?i",$refs_id);
		$db->query("UPDATE ss_users SET ref_pay=ref_pay+$refs_per WHERE id=?i",$refs_id);
		$db->query("UPDATE ss_users SET withdraw=withdraw+$refs_per WHERE id=?i",$refs_id);
		$db->query("INSERT INTO deposits (userid, curatorid, summa, unixtime, status) VALUES(?i,?i,?s,?s,?i)", $refs_id, 0, $refs_per, time(),2);
	}
	}}

?>