<?
if(!defined('SKYLIGHT')){
exit();
}

if($with_sum>$min_payeer){
		$wallet=$db->getOne("SELECT wallet FROM ss_users WHERE id=?i", $id);	
		require_once('classes/cpayeer.php');	
		$payeer = new CPayeer($accountNumber, $apiId, $apiKey);
		if ($payeer->isAuth()){
			$arBalance = $payeer->getBalance();
		}
		$balance = $arBalance["balance"]["RUB"]["DOSTUPNO"];

		if($with_sum<$balance){
		$m_curr='RUB'; 
		$com='Эй, водила! Ты глянька тебе пришла выплата с проекта SPEED CAR';
		$arTransfer = $payeer->transfer(array(
		'curIn' => $m_curr,
		'sum' => $with_sum,
		'curOut' => $m_curr,
		'to' => $wallet,
		'comment' => $com,
		'anonim' => 'Y', // анонимный перевод
	));
	
	if (!empty($arTransfer['historyId']) && $arTransfer['historyId']>0)
	{
		$time_in=time();
		$db->query("UPDATE ss_users SET updat=$time_in WHERE id=?i",$id);
		$db->query("UPDATE ss_users SET withdraw=withdraw+$with_sum WHERE id=?i",$id); 
		$time=time();
		$db->query("INSERT INTO pay (userid,type,data,summa) VALUES ('$id', 'Ежедневная выплата', '$time', '$with_sum')");
		//$db->query("INSERT INTO deposits (userid, curatorid, summa, unixtime, status) VALUES(?i,?i,?s,?s,?i)", $id, 0, $with_sum, time(),1);
	}else{

		}
	}
	  
	
	}

?>