<?php 
if(!defined('SKYLIGHT')){ 
echo ('Выявлена попытка взлома!'); 
exit(); 
} 
date_default_timezone_set("Europe/Moscow");
include_once 'security.php';


$host = 'localhost'; //хост базы
$db = 'speed';
$user = 'root';
$pass = '';
$charset = 'UTF8';
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$opt = array( PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC );
$pdo = new PDO($dsn, $user, $pass, $opt);
$pdo->exec("set names utf8");
$db = new SafeMySQL(array('user' => $user, 'pass' => $pass, 'db' => $db, 'charset' => 'utf8'));
$start=$db->getOne("SELECT start FROM config WHERE id=?i",1);


//Название проекта 
$sitename="SPEED CAR ONLINE"; 
//Описание проекта 
$description="Инвестиционная платформа"; 
//Дата старта 
//$privetstvie='Проект стартовал в '.date('d.m.Y H:i',$start).''; //Тупо пишем текстом что нужно, например дату старта, как нравится 
//Вкл/выкл капчи (1 - вкл, 0 - выкл) 
$use_kapcha=0; 
//Режим работы сайта. 1 - сайт работает, 0 - регистрация закрыта 
$itworks=1; 
//Тип соединения (http или https) 
$http_s="https"; 

//Настройки PAYEER 
//ПРИЕМ СРЕДСТВ (мерчант): 
$m_shop = ''; //ID магазина в системе Payeer 
$m_desc = 'Пополнение счета в '.$sitename; //Текст комментария к платежу 
$m_key = ''; 
//ВЫПЛАТА (api): 
$accountNumber = ''; //Счет, с которого будут происходить выплаты 
$apiId = ''; //ID API 
$apiKey = ''; //Секретный ключ API 
$m_curr='RUB'; 

//КОШЕЛЕК ПРОЕКТА 
$koshelek_admina=''; //Кошелек админа (Сюда будут капать админские. Также только этот логин будет иметь доступ в админку) 

$adminmail="SUPPORT@SPEEDCAR.ONLINE"; //Почта админа 


//Выплаты по крону? 0 - по крону, 1 - кешем 
$nocron=0; 



/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/ 
$targetDate=strtotime(date("12.10.2018")); //start date 

$mindep=15; //Минимальный размер депозита 
$maxdep=10000; //Максимальный размер депозита 

$minpay=1; //НЕ ДЛЯ БОНУСНИКА
$maxpay=1000;//НЕ ДЛЯ БОНУСНИКА

$refpercent=10; //Реф. процент 
$admpercent=10; //Админский процент 


$depperiod=30; //Время вклада  //НЕ ДЛЯ БОНУСНИКА

$percent_u = '20'; //+ к депозиту //НЕ ДЛЯ БОНУСНИКА
$min_payeer = 1; // Минимальная выплата PAYEER //НЕ ДЛЯ БОНУСНИКА

$max_summ = 151; // Максимальная сумма выплаты //НЕ ДЛЯ БОНУСНИКА

$cf=0.000001; // скорост за 1 руб

?>