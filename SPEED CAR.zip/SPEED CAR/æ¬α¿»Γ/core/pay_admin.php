<?
if(!defined('SKYLIGHT')){
exit();
}
$summa_admin=$db->getOne("SELECT admin_per FROM `config` WHERE id=?i", 1);

if($summa_admin>$min_payeer){
	
		require_once('classes/cpayeer.php');	
		$payeer = new CPayeer($accountNumber, $apiId, $apiKey);
		if ($payeer->isAuth()){
			$arBalance = $payeer->getBalance();
		}
		$balance = $arBalance["balance"]["RUB"]["DOSTUPNO"];

		
		$m_curr='RUB'; 
		$com='Админские с проекта Coin Fishing';
		$arTransfer = $payeer->transfer(array(
		'curIn' => $m_curr,
		'sum' => $summa_admin,
		'curOut' => $m_curr,
		'to' => $koshelek_admina,
		'comment' => $com,
		'anonim' => 'Y', // анонимный перевод
	));
	if (!empty($arTransfer['historyId']) && $arTransfer['historyId']>0)
	{
		$db->query("UPDATE config SET admin_per=admin_per-$summa_admin WHERE id=?i",1);
		$db->query("UPDATE config SET pay_adm=pay_adm+$summa_admin WHERE id=?i",1);
	}
	}
?>