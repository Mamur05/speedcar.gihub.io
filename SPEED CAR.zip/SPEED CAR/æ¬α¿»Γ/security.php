<?php
//от Марата
function check1_text($text) {
	  $arraysql = array('UNION','SELECT','OUTFILE','LOAD_FILE','GROUP BY','ORDER BY','INFORMATION_SCHEMA.TABLES','BENCHMARK','FLOOR','SLEEP','CHAR');
	  $replacesql ='';
	  $text2=$text;
	  $text2=mb_strtoupper($text2);
	  $text2=str_ireplace($arraysql, $replacesql, $text2,$count);
	  if($count!=0){ echo "Ошибка, сработала защита.<br>Подозрение на SQL inj или XXS "; exit;}
	  
	  $array_find = array("'",'"','/**/','0x','/*','--');
	  $array_replace ='';
	  $text=str_ireplace($array_find, $array_replace, $text);
	return $text;
}



foreach($_GET as $i => $value){ $_GET[$i]=check1_text($_GET[$i]);}
foreach($_POST as $i => $value){ $_POST[$i]=check1_text($_POST[$i]);}
foreach($_COOKIE as $i => $value){ $_COOKIE[$i]=check1_text($_COOKIE[$i]);}





?>
