<?session_start(); 
define('SKYLIGHT',dirname(__FILE__)); 
include(dirname(__FILE__).'/core/ini.php'); 
include(dirname(__FILE__).'/core/cache.php'); 

# Старт сессии
@session_start();

# Старт буфера
@ob_start();

$page = $_GET['page'];
define( 'ROOT', 'https://'.$_SERVER['HTTP_HOST'] );
define( 'ROOT_DIR', $_SERVER['DOCUMENT_ROOT'] );

# Default
$_OPTIMIZATION = array();
$_OPTIMIZATION["title"] = "Инвестиционная платформа";
$_OPTIMIZATION["description"] = "";
$_OPTIMIZATION["keywords"] = "";

$sql = $pdo->Query("SELECT * FROM `tb_online` WHERE `ip` = '".$_SERVER['REMOTE_ADDR']."'");
if($sql->RowCount() == 0) {
$pdo->Query("INSERT INTO `tb_online` (ip, date) VALUES ('".$_SERVER['REMOTE_ADDR']."', '".time()."')");
} else { $pdo->Query("UPDATE `tb_online` SET date = '".time()."' WHERE ip ='".$_SERVER['REMOTE_ADDR']."'"); }
$delete = time() - 30;
$pdo->Query("DELETE FROM `tb_online` WHERE date < '$delete'");

$sql = $pdo->Query("SELECT * FROM `tb_online`");
$online = $sql->RowCount();

include('templ/main/head.php'); 
if(isset($page)){ 
if(file_exists(dirname(__FILE__)."/pages/".$page.".php")){ 
include(dirname(__FILE__)."/pages/".$page.'.php'); 
}else{ 
include(dirname(__FILE__).'/pages/404.php'); 
} 
}else{ 
include(dirname(__FILE__).'/pages/main.php'); 
}
include('templ/main/foot.php'); 

# Заносим контент в переменную
$content = ob_get_contents();

# Очищаем буфер
ob_end_clean();
	
	# Заменяем данные
	$content = str_replace("{!TITLE!}",$_OPTIMIZATION["title"],$content);
	$content = str_replace('{!DESCRIPTION!}',$_OPTIMIZATION["description"],$content);
	$content = str_replace('{!KEYWORDS!}',$_OPTIMIZATION["keywords"],$content);
	
	
// Выводим контент
echo $content;