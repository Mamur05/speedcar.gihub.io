<?php if(!defined('SKYLIGHT')){
echo ('Выявлена попытка взлома!');
exit();
}
$_OPTIMIZATION["title"] = "Контакты"; 
?>
<div class="container" style="line-height: 22px;position: relative;">
<div class="row">
<div style="background: linear-gradient(135deg,#fff 0%,#eef3fa 100%);border-radius: 6px;box-shadow: 0 10px 35px rgba(170,177,187,.18);padding: 40px;">
<h4 style="color: #000;font-weight: 400;font-size: 24px;line-height: 55px;">Контакты</h4>
Если Вы нуждаетесь в дополнительной информации, которая касается регистрации и использования сервиса, процессов открытия вклада и вывода прибыли, а также схемы работы партнерской программы, предлагаем Вам ознакомиться с разделом "FAQ". В случае, если необходимая информация не была найдена, Вы можете обратиться за разъяснениями в службу клиентской поддержки, по указанным контактам<br>
<strong>Техподдержка: speedcar.online@yandex.ru</strong> <br><br>
Для того чтоб быть вкурсе всех новостей проекта и для более оперативной технической поддержки, рекомендуем вступить в наше сообщество<br> 
<strong>Вконтакте: vk.com/speedcar_online</strong>
<br><br>
</div>
</div>
</div>