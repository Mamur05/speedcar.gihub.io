<?php if(!defined('SKYLIGHT')){
echo ('Выявлена попытка взлома!');
exit();
}
$_OPTIMIZATION["title"] = "Промо материалы"; 
if(empty($id)){?>
	<script type="text/javascript">
	location.replace("/");
	</script>
	<noscript>
	<meta http-equiv="refresh" content="0; url=/">
	</noscript>
	<?
exit();
}
?>

<div class="container" style="line-height: 22px;position: relative;">
<div class="row">
<div style="background: linear-gradient(135deg,#fff 0%,#eef3fa 100%);border-radius: 6px;box-shadow: 0 10px 35px rgba(170,177,187,.18);padding: 40px; overflow: hidden;">
<h4 style="color: #000;font-weight: 400;font-size: 24px;line-height: 55px;">Промо материалы</h4>
<div class="row">
<div style="width: 27%;float: left; min-height: 1px; padding-right: 15px;">

<div class="single-info-block text-center" style="box-shadow: none;padding-top: 0px;padding: 20px 10px;background: #5858d7;border-radius: 6px;box-shadow: 10px 11px 35px rgba(170, 177, 187, 0.69);">
<div class="dropOut">
 <ul>
 <li><span aria-hidden="true" class="lnr lnr-car"></span><a href="/my"> Мой аккаунт</a></li>
 <li><span aria-hidden="true" class="lnr lnr-briefcase"></span><a href="/out"> Вывод средств</a></li>
 <li><span aria-hidden="true" class="lnr lnr-chart-bars"></span><a href="/history"> История операций</a></li>
 <li><span aria-hidden="true" class="lnr lnr-users"></span><a href="/referals"> Партнерская программа</a></li>
 <li style="border-radius: 4px;background: rgba(255, 255, 255, .15);transition: all .3s;-webkit-transition: all .3s;-moz-transition: all .3s;box-shadow: 0px 0px 15px 2px rgba(255, 255, 255, .15);"><span aria-hidden="true" class="lnr lnr-picture"></span><a href="/promo"> Промо материалы</a></li>
 <li><span aria-hidden="true" class="lnr lnr-exit"></span><a href="/exit"> Выход из системы</a></li>
 </ul>
 </div>
 </div>

</div>
<div style="width: 73%;float: left;min-height: 1px;padding-right: 15px;padding-left: 15px;position: relative;">
<img style="top: -30px;position:absolute;opacity: 0.05;width: 97%;" src="/images/huracan-1.png">
<div style="z-index: 999999;position: relative;">
Приглашайте друзей, знакомых и зарабатывайте <font color="000000" size="4"><b>10%</b></font> от их пополнений, моментально на PAYEER WALLET кошелек. Автоматические выплаты.
</div>

<div style="z-index: 99999;position: relative;margin-top: 20px;">
<h1><b style="font-size: 15px;font-weight: 600;color: #000;"> Ваша партнерская ссылка</b></h1>

<input class="form-control" value="<?=$http_s?>://<?=$host?>/?ref=<?=$id?>" onclick="select()" size="30" type="text" style="margin-top: 8px;width: 100%;padding: 10px 20px;border: 2px solid #f0f0ef;border-radius: 2px;background: #eef3fa52;font-size: 15px;" placeholder="">
<br>
<br>
<h1><b style="font-size: 15px;font-weight: 600;color: #000;"> Баннер 468x60 </b></h1>

<font>
<img src="/images/468.gif" style="margin-top: 10px;"><br>
<input style="margin-top: 16px;width: 100%;padding: 10px 20px;border: 2px solid #f0f0ef;border-radius: 2px;background: #eef3fa52;font-size: 15px;" value="<?=$http_s?>://<?=$host?>/images/468.gif" type="text" placeholder="">
<br>
<br>
</font>
</div>
            

</div>
</div>
</div>
</div>
</div>