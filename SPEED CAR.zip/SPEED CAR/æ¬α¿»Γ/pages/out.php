<?php if(!defined('SKYLIGHT')){
echo ('Выявлена попытка взлома!');
exit();
}
$_OPTIMIZATION["title"] = "Вывод средств"; 
if(empty($id)){?>
	<script type="text/javascript">
	location.replace("/");
	</script>
	<noscript>
	<meta http-equiv="refresh" content="0; url=/">
	</noscript>
	<?
exit();
}
?>
<?
$time_in=time();
$speed=$db->getOne("SELECT speed FROM `ss_users` WHERE id=?s", $id);
$updat=$db->getOne("SELECT updat FROM `ss_users` WHERE id=?s", $id);
$with_sum=($time_in-$updat)*$speed;
$with_sum2=number_format($with_sum, 2, '.', '');
$wallet_out=$db->getOne("SELECT wallet FROM `ss_users` WHERE id=?s", $id);
$time_ww=$updat+86400;
$arHash = array($with_sum2,'nijeryh823yrhasnfoiuyew8a7gfrJAFJIOEH9AD');
$sign_hash = strtoupper(hash('sha256', implode(':', $arHash)));
?>
<div class="container" style="line-height: 22px;position: relative;">
<div class="row">
<div style="background: linear-gradient(135deg,#fff 0%,#eef3fa 100%);border-radius: 6px;box-shadow: 0 10px 35px rgba(170,177,187,.18);padding: 40px; overflow: hidden;">
<h4 style="color: #000;font-weight: 400;font-size: 24px;line-height: 55px;">Вывод средств</h4>
<div class="row">
<div style="width: 27%;float: left; min-height: 1px; padding-right: 15px;">

<div class="single-info-block text-center" style="box-shadow: none;padding-top: 0px;padding: 20px 10px;background: #5858d7;border-radius: 6px;box-shadow: 10px 11px 35px rgba(170, 177, 187, 0.69);">
<div class="dropOut">
 <ul>
 <li><span aria-hidden="true" class="lnr lnr-car"></span><a href="/my"> Мой аккаунт</a></li>
 <li style="border-radius: 4px;background: rgba(255, 255, 255, .15);transition: all .3s;-webkit-transition: all .3s;-moz-transition: all .3s;box-shadow: 0px 0px 15px 2px rgba(255, 255, 255, .15);"><span aria-hidden="true" class="lnr lnr-briefcase"></span><a href="/out"> Вывод средств</a></li>
 <li><span aria-hidden="true" class="lnr lnr-chart-bars"></span><a href="/history"> История операций</a></li>
 <li><span aria-hidden="true" class="lnr lnr-users"></span><a href="/referals"> Партнерская программа</a></li>
 <li><span aria-hidden="true" class="lnr lnr-picture"></span><a href="/promo"> Промо материалы</a></li>
 <li><span aria-hidden="true" class="lnr lnr-exit"></span><a href="/exit"> Выход из системы</a></li>
 </ul>
 </div>
 </div>

</div>
<div style="width: 73%;float: left;min-height: 1px;padding-right: 15px;padding-left: 15px;position: relative;">
<img style="top: -30px;position:absolute;opacity: 0.05;width: 97%;" src="/images/huracan-1.png">
<div style="z-index: 999999;position: relative;">
В данном разделе Вы можете произвести выплату своих средств на кошелек PAYEER WALLET (ваш кошелек: <font color="000"><b><?=$wallet_out?></b></font>). Минимальная сумма для выплаты <font color="000"><b>1.00</b></font> RUB
</div>

<div class="col-md-23" style="width: 96.5%;margin-left: 0px;z-index: 999999;position: relative;margin-top: 0px;">
<div class="c-content-feature-2" style="padding: 0px;">
<table>
<tbody>
<tr><td colspan="6" style="text-align: center;"><div>
<span>Ваш баланс на вывод составляет: <b style="line-height: 55px;font-weight: 700;"><font size="+2"><span class="profit"><?=$with_sum?></span></font></b> RUB</div>	
</td>
</tr>
</tbody>
</table>
</div>
</div>
<center style="z-index: 999999;position: relative;">
 <?
if($with_sum<1){?>

<form action="" method="post" id="info">
<?}?>

<form action="" method="post" id="info">
<?
if($time_ww<time()){?>



<input type="hidden" name="do" value="payeer_out">
<input type="hidden" name="antipovtor" value="<?=time();?>">
<input type="hidden" name="m_amount" value="<?=$with_sum2;?>">
<input type="hidden" name="hash" value="<?=$sign_hash;?>">

<button type="submit" name="submit2" id="info" style="margin-top: 0px;padding: 0 50px;border: none;cursor: pointer;outline: none;" class="buy-car"> Получить <?=$with_sum2?> руб. </button>


<?}else{?>
<br>
<div style="font-weight: 600;letter-spacing: 1.5px;color: #000000;overflow: hidden;width: 100%;padding: 30px;background: #fbc130;border-radius: 6px;padding-left: 50px;">
<span class="lnr lnr-warning" style="font-size: 35px;position: absolute; margin-left: -45px; margin-top: -10px;"></span>
<font>Следующая выплата будет доступна с </font>
<font><?=date('d.m.Y H:i',$time_ww)?> по MSK</font>
</div>


<?}?>
</form>
</center>
            

</div>
</div>
</div>
</div>
</div>