<?php if(!defined('SKYLIGHT')){
echo ('Выявлена попытка взлома!');
exit();
}
$_OPTIMIZATION["title"] = "Партнерская программа";
if(empty($id)){?>
	<script type="text/javascript">
	location.replace("/");
	</script>
	<noscript>
	<meta http-equiv="refresh" content="0; url=/">
	</noscript>
	<?
exit();
}
?>
<?
$ihr=$db->getOne("SELECT i_have_refs_as_curator FROM ss_users WHERE id=?i",$id);
$refs_w=$db->getOne("SELECT refs_wait FROM `ss_users` WHERE id=?i", $id);
$refs_out=$db->getOne("SELECT ref_pay FROM `ss_users` WHERE id=?i", $id);

?>
<div class="container" style="line-height: 22px;position: relative;">
<div class="row">
<div style="background: linear-gradient(135deg,#fff 0%,#eef3fa 100%);border-radius: 6px;box-shadow: 0 10px 35px rgba(170,177,187,.18);padding: 40px; overflow: hidden;">
<h4 style="color: #000;font-weight: 400;font-size: 24px;line-height: 55px;">Партнерская программа</h4>
<div class="row">
<div style="width: 27%;float: left; min-height: 1px; padding-right: 15px;">

<div class="single-info-block text-center" style="box-shadow: none;padding-top: 0px;padding: 20px 10px;background: #5858d7;border-radius: 6px;box-shadow: 10px 11px 35px rgba(170, 177, 187, 0.69);">
<div class="dropOut">
 <ul>
 <li><span aria-hidden="true" class="lnr lnr-car"></span><a href="/my"> Мой аккаунт</a></li>
 <li><span aria-hidden="true" class="lnr lnr-briefcase"></span><a href="/out"> Вывод средств</a></li>
 <li><span aria-hidden="true" class="lnr lnr-chart-bars"></span><a href="/history"> История операций</a></li>
 <li style="border-radius: 4px;background: rgba(255, 255, 255, .15);transition: all .3s;-webkit-transition: all .3s;-moz-transition: all .3s;box-shadow: 0px 0px 15px 2px rgba(255, 255, 255, .15);"><span aria-hidden="true" class="lnr lnr-users"></span><a href="/referals"> Партнерская программа</a></li>
 <li><span aria-hidden="true" class="lnr lnr-picture"></span><a href="/promo"> Промо материалы</a></li>
 <li><span aria-hidden="true" class="lnr lnr-exit"></span><a href="/exit"> Выход из системы</a></li>
 </ul>
 </div>
 </div>

</div>
<div style="width: 73%;float: left;min-height: 1px;padding-right: 15px;padding-left: 15px;position: relative;">
<img style="top: -30px;position:absolute;opacity: 0.05;width: 97%;" src="/images/huracan-1.png">
<div style="z-index: 999999;position: relative;">
Приглашайте друзей, знакомых и зарабатывайте <font color="000000" size="4"><b>10%</b></font> от их пополнений, моментально на PAYEER WALLET кошелек. Автоматические выплаты.
</div>
<div class="product-caption" style="margin-top: 0px;margin-bottom:0px; padding: 20px 5px;">
<p><b>Количество рефералов:</b><i id="d"><?=$ihr?> ЧЕЛ.</i></p>
<p><b>В ожидании начисления:</b><i id="d"><?=$refs_w?> RUB</i></p>
<p><b>Выплачено реф.дохода:</b><i id="d"><?=$refs_out?> RUB</i></p>
</div>


<div class="col-md-23" style="width: 100%;margin-left: 0px; padding: 0px 5px;">
<div class="c-content-feature-2" style="padding: 0px;">
<table>
<thead> 
<tr style="border-bottom: 2px solid #e4e6eb;">
<td>Логин (PAYEER)</td>
<td>Дата регистрации</td>
<td>Откуда пришел</td>
<td>Доход</td>
</tr> 
</thead>
<tbody>  
 <? if($ihr>0){
$myrefsrow=$db->query("SELECT * FROM ss_users WHERE curator=?i ORDER BY id DESC",$id); 
while($myrefs=$db->fetch($myrefsrow)){?>   
<tr id="hov">
<td><?=$myrefs['wallet']?></td>
<td><?=date('d.m.Y H:i:s',$myrefs['reg_unix'])?></td>
<td><?=$myrefs['came']?> </td>
<td><?=$myrefs['curator_pay']?> RUB</td>
</tr>
  <?}}else{?>
  <tr align="center" id="hov">
    <td colspan="4" style="text-align: center;">У вас нет рефералов! </td>
  </tr>

<?}?>

</tbody>
</table>
</div>
</div>
           
</div>
</div>
</div>
</div>
</div>