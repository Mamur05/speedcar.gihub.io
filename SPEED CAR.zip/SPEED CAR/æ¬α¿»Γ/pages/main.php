<?php if(!defined('SKYLIGHT')){
echo ('Выявлена попытка взлома!');
exit();
}
?>

<div class="container"> 
<div class="row" style="overflow: hidden;padding-bottom: 30px;">
<div class="col-md-4 col-sm-4 text-center">
<div class="blocks fadeInRight wow" style="visibility: visible; animation-name: fadeInRight;">
<div style="text-align: left;padding-left: 110px;">
<h4 style="color: #000;font-weight: 500;font-size: 20px;">Простая регистрация</h4>
<h3 style="font-size: 14px;color: #000000;font-weight: 500;">Начать зарабатывать с нами очень легко!</h3>
</div>
<img width="100" src="/images/one-ill-about.svg" style="position: absolute;margin-left: -190px;margin-top: -88px;">
</div>
</div>
<div class="col-md-4 col-sm-4 text-center">
<div class="blocks fadeInRight wow" style="visibility: visible; animation-name: fadeInRight;">
<div style="text-align: left;padding-left: 110px;">
<h4 style="color: #000;font-weight: 500;font-size: 20px;">Удобный интерфейс</h4>
<h3 style="font-size: 14px;color: #000000;font-weight: 500;">Удобный, простой и понятный интерфейс!</h3>
</div>
<img width="100" src="/images/three-ill-about-03-03.svg" style="position: absolute;margin-left: -190px;margin-top: -88px;">
</div>
</div>
<div class="col-md-4 col-sm-4 text-center">
<div class="blocks fadeInRight wow" style="visibility: visible; animation-name: fadeInRight;">
<div style="text-align: left;padding-left: 110px;">
<h4 style="color: #000;font-weight: 500;font-size: 20px;">Высокая прибыль</h4>
<h3 style="font-size: 14px;color: #000000;font-weight: 500;">Окупаемость вложений всего 12 дней!</h3>
</div>
<img width="100" src="/images/two-ill-about-02.svg" style="position: absolute;margin-left: -190px;margin-top: -88px;">
</div>
</div>
</div>
<div class="row">
<h1 style="color: #000;font-weight: 300;font-family: 'Rubik', sans-serif;font-size: 30px;letter-spacing: 0.5;text-align: left;line-height: 65px;font-weight: 400;font-size: 24px;">Финансовые операции</h1>
<div style="background: linear-gradient(135deg,#fff 0%,#eef3fa 100%);border-radius: 6px;box-shadow: 0 10px 35px rgba(170,177,187,.18);padding: 20px 0px;">

			
<table class="table">
<thead style="color: #9e9e9f;"> 
<tr>
<td style="text-align: center;">№</td>
<td>Дата</td>
<td>Кошелек</td>
<td>Сумма</td>
<td>Тип операции</td>
</tr> 
</thead>
<tbody>  
<? 
$checkdeps=$db->getOne("SELECT * FROM `pay` ORDER BY id DESC limit 1"); 
if($checkdeps>0){ 
$depositsrow=$db->query("SELECT * FROM `pay` ORDER BY id DESC limit 8");
while($deposits=$db->fetch($depositsrow)){
$wallet=substr($db->getOne("SELECT wallet FROM `ss_users` WHERE id=?i",$deposits['userid']), 0, -3);
?>   
 
<tr>
<td style="text-align: center;"> <?=$deposits['id']?></td>
<td> <?=date('d.m.Y H:i',$deposits['data'])?></td>
<td><?=$wallet?> <font color="#cf3b28"> • • •</font></td>
<td style="font-weight: 600;font-family: 'Montserrat', sans-serif;"><span style="padding:3px 10px;background:#eef3fa;border-radius:6px;"><?=$deposits['summa']?> RUB</span></td>
<td> <?=$deposits['type']?></td>
</tr>
<?}}else{?> 
      
<td colspan="5" style="text-align: center;">Статистика финансовых операций еще не сформирована :(</td> 
 
<?}?>   
 
 
</tbody>

</table>
</div>
</div>
<div class="row" style="overflow: hidden;margin-top: 50px;">
                <div class="col-md-6 wow  fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">
                    <h4 style="color: #000;font-weight: 400;font-size: 24px;">О сервисе</h4>

                    <p style="line-height: 22px;">SPEED CAR ONLINE — это экономический симулятор с возможностью заработка и вывода реальных денег. Для игроков предоставляется возможность заработка как с вложениями, так и без. Прокачивайте свой автомобиль и он будет приносить вам до 250% прибыли в месяц! Окупаемость ваших инвестиций всего 12 дней.</p>
                </div>

                <div class="col-md-6 wow  fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">
                    <h4 style="color: #000;font-weight: 400;font-size: 24px;">О рисках</h4>

                    <p style="line-height: 22px;">Несмотря на то, что SPEED CAR ONLINE – это игра, даже здесь есть риски. Мы этого не скрываем, но мы смело заявляем, что наш проект — стабильный и всегда выполняет свои обязательства, это подтвердят активные игроки, которые уже стабильно зарабатывают на нашем проекте. Ваш доход зависит только от Вас и от глубины участия в проекте!</p>
                </div>
            </div>

</div>