<?php if(!defined('SKYLIGHT')){
echo ('Выявлена попытка взлома!');
exit();
}
$_OPTIMIZATION["title"] = "Мой аккаунт"; 
if(empty($id)){?>
	<script type="text/javascript">
	location.replace("/");
	</script>
	<noscript>
	<meta http-equiv="refresh" content="0; url=/">
	</noscript>
	<?
exit();
}
?>

<style>
img.rot {
    animation: 1s linear 0s normal none infinite running rot;
    -webkit-animation: 2s linear 0s normal none infinite running rot;
    width: 50px;
    position: absolute;
    margin-left: -70px;
}

@keyframes rot {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}
@-webkit-keyframes rot {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}
</style>
<script type="text/javascript">
function number_format( number, decimals, dec_point, thousands_sep ) {	// Format a number with grouped thousands
	var i, j, kw, kd, km;

	if( isNaN(decimals = Math.abs(decimals)) ){
		decimals = 2;
	}
	if( dec_point == undefined ){
		dec_point = ".";
	}
	if( thousands_sep == undefined ){
		thousands_sep = " ";
	}

	i = parseInt(number = (+number || 0).toFixed(decimals)) + "";

	if( (j = i.length) > 3 ){
		j = j % 3;
	} else{
		j = 0;
	}

	km = (j ? i.substr(0, j) + thousands_sep : "");
	kw = i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousands_sep);
	//kd = (decimals ? dec_point + Math.abs(number - i).toFixed(decimals).slice(2) : "");
	kd = (decimals ? dec_point + Math.abs(number - i).toFixed(decimals).replace(/-/, 0).slice(2) : "");


	return km + kw + kd;
}
var newn=0.105288;

setInterval(function() {newn=newn+0.000041;document.getElementById("upt").innerHTML=number_format(newn, 6);}, 1000);

</script>
<?
$up=$db->getRow("SELECT * FROM ss_users WHERE id=?i",$id);
$second=time()-$up['updat'];
$prof=$up['speed'];
$bal=$up['balans'];
$bal = number_format($bal, 2, '.', '');
$balans=($second*$up['speed']);
//$bal2=$bal-0.01;
$balans1 = number_format($balans, 6, '.', '');
//$balans2 = number_format($balans, 2, '.', '')-0.01;
$profhour = $prof*3600;
$profhour = number_format($profhour, 4, '.', '');
$profday = $prof*3600*24;
$profday = number_format($profday, 4, '.', '');
$profday30 = $prof*3600*24*30;
$profday30 = number_format($profday30, 3, '.', '');
$profday180 = $prof*3600*24*180;
$profday180 = number_format($profday180, 3, '.', '');
$profday365 = $prof*3600*24*365;
$profday365 = number_format($profday365, 3, '.', '');
$avatar=$db->getOne("SELECT avatar FROM ss_users WHERE id=?i",$id);
?>
<div class="container" style="line-height: 22px;position: relative;">
<div class="row">
<div style="background: linear-gradient(135deg,#fff 0%,#eef3fa 100%);border-radius: 6px;box-shadow: 0 10px 35px rgba(170,177,187,.18);padding: 40px; overflow: hidden;">
<h4 style="color: #000;font-weight: 400;font-size: 24px;line-height: 55px;">Мой аккаунт</h4>
<div class="row">
<div style="width: 27%;float: left; min-height: 1px; padding-right: 15px;">

<div class="single-info-block text-center" style="box-shadow: none;padding-top: 0px;padding: 20px 10px;background: #5858d7;border-radius: 6px;box-shadow: 10px 11px 35px rgba(170, 177, 187, 0.69);">
<div class="dropOut">
 <ul>
 <li style="border-radius: 4px;background: rgba(255, 255, 255, .15);transition: all .3s;-webkit-transition: all .3s;-moz-transition: all .3s;box-shadow: 0px 0px 15px 2px rgba(255, 255, 255, .15);"><span aria-hidden="true" class="lnr lnr-car"></span><a href="/my"> Мой аккаунт</a></li>
 <li><span aria-hidden="true" class="lnr lnr-briefcase"></span><a href="/out"> Вывод средств</a></li>
 <li><span aria-hidden="true" class="lnr lnr-chart-bars"></span><a href="/history"> История операций</a></li>
 <li><span aria-hidden="true" class="lnr lnr-users"></span><a href="/referals"> Партнерская программа</a></li>
 <li><span aria-hidden="true" class="lnr lnr-picture"></span><a href="/promo"> Промо материалы</a></li>
 <li><span aria-hidden="true" class="lnr lnr-exit"></span><a href="/exit"> Выход из системы</a></li>
 </ul>
 </div>
 </div>

</div>
<div style="width: 73%;float: left;min-height: 1px;padding-right: 15px;padding-left: 15px;position: relative;">
<img style="top: -30px;position:absolute;opacity: 0.05;width: 97%;" src="/images/huracan-1.png">
<div style="z-index: 999999;position: relative;">
На данный момент мощность вашего автомобиля составляет: <font color="000000" size="4"><b><?=$prof?></b></font> л.с = <font color="000000" size="4"><b><?=$prof?></b></font> RUB в секунду.
 Для увеличения мощности вашего автомобиля  <a href="#oplata-in" style="color: #000000;text-decoration: none;"><b>оплатите</b></a> любую сумму от 10 до 10000 рублей!

</div>
<div class="col-md-23" style="width: 96.5%;margin-left: 0px;z-index: 999999;position: relative;margin-top: 10px;">
<div class="c-content-feature-2" style="padding: 0px;">


<table>
<tbody>
<tr><td colspan="6" style="text-align: center;"><div >
<span>Ваш доход на данный момент составляет: </span><b style="padding-left: 90px;line-height: 55px;font-weight: 700;"> <img src="/images/koleso.svg" class="rot"><font size="+2"><span class="profit" data-prc=<?=$prof?> data-tm=<?=$second?> data-sum="<?=$bal?>"><?=$balans1?></span></font></b> RUB</div>	
</td>
</tr>
</tbody>
</table>
</div>
</div>

<div class="row" style="margin-top: 0px;">
                <div class="col-md-12">
                    </div>
                </div>
            

<center style="z-index: 999999;position: relative;">
<a class="buy-car" href="#oplata-in" style="margin-top: 10px;padding: 0 50px;">
Оплатить мощность
</a>
</center>

<div class="product-caption">
<p><b>Сумма ваших пополнений:</b><i id="d"><?=$allinuser?> RUB</i></p>
<p><b>Доход за 60 минут:</b><i id="d"><?=$profhour?> RUB</i></p>
<p><b>Доход за 24 часа:</b><i id="d"><?=$profday?> RUB</i></p>
<p><b>Доход за 30 дней:</b><i id="d"><?=$profday30?> RUB</i></p>
<p><b>Доход за 180 дней:</b><i id="d"><?=$profday180?> RUB</i></p>
<p><b>Доход за 365 дней:</b><i id="d"><?=$profday365?> RUB</i></p>
</div> 
</div>
</div>
</div>
</div>
</div>
</div>