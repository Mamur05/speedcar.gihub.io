<?
if(!defined('SKYLIGHT')){
exit();
}
date_default_timezone_set("Europe/Moscow");
?>
<html>
<head>
 
    <title>SPEED CAR ONLINE - Прокачай свою тачку</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<link rel="shortcut icon" href="/logo.png">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
        <link href="/style/style.css" rel="stylesheet" type="text/css">
	    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
		<link href="https://fonts.googleapis.com/css?family=Alegreya+Sans+SC" rel="stylesheet"> 
		<link rel="stylesheet" href="https://cdn.linearicons.com/free/1.0.0/icon-font.min.css">
		<link rel="stylesheet" href="/style/bootstrap.min.css">
		<script>
		$(document).ready(function(){
			setInterval(function(){
				$('.countdown').each(function(){
					var time=$(this).text().split(':');
					var timestamp=time[0]*3600+ time[1]*60+ time[2]*1;timestamp-=timestamp>0;
					var hours=Math.floor(timestamp/3600);
					var minutes=Math.floor((timestamp- hours*3600)/ 60);
					var seconds=timestamp- hours*3600- minutes*60;if(hours<10){hours='0'+ hours;}
					
				if(minutes<10){minutes='0'+ minutes;}
				if(seconds<10){seconds='0'+ seconds;}
				if(timestamp>0){
				$(this).text(hours+':'+ minutes+':'+ seconds);
				}else{
				$(this).text('00:00:00');	
				}
				}
				);
			$(".profit").each(function(){
					var a=parseInt($(this).attr("data-tm"))+1;
					if(a<8640000){
						var b=a*$(this).attr("data-prc");
						
						$(this).attr("data-tm",a);
						$(this).html(b.toFixed(6))}})},1000);

		})
		</script>
		
	<script>
(function($)
{
$.fn.jMagnify = function(o) {
 
o = $.extend({
centralEffect: {'font-size': '200%'},
lat1Effect: {'font-size': '180%'},
lat2Effect: {'font-size': '150%'},
lat3Effect: {'font-size': '120%'},
resetEffect: {'font-size': '100%'}
}, o);
return this.each(function(i) {
var el = $(this);
var uuid = (el.attr('id') || el.attr('class') || 'internalName') + '_jMagnify';
var myText = "";
var aStr = el.text().split("");
 
for (var len in aStr)
myText += "<span class='" + uuid + "'>" + aStr[len] + "</span>";
el.html(myText);
$('.' + uuid).hover(function(){
$(this).css(o.centralEffect)
.next().css(o.lat1Effect)
.next().css(o.lat2Effect)
.next().css(o.lat3Effect);
$(this).prev().css(o.lat1Effect)
.prev().css(o.lat2Effect)
.prev().css(o.lat3Effect);
},
function() {
$(this).css(o.resetEffect)
.next().css(o.resetEffect)
.next().css(o.resetEffect)
.next().css(o.resetEffect);
$(this).prev().css(o.resetEffect)
.prev().css(o.resetEffect)
.prev().css(o.resetEffect);
});
});
};
})(jQuery);
 
</script>	


		
</head>
<body>	
<div id="loader-wrapper">
<div id="loader"></div>
</div>

<?if(!empty($_error)){?><div class="stat" style="display: inline-block;font-size: 14px;color: #ffffff;z-index: 10;right: 23px;top: 20px;line-height: 1.72857143;position: fixed;width: 300px;background: #00000052;padding: 15px 0px;border-radius: 4px;z-index: 99999999;font-weight: 400;"><center><font><?=$_error?></font></div></center><?}?>


<?
				
				$opened=$db->numRows($db->query("SELECT id FROM deposits WHERE status=?i",0));
				$closed=$db->numRows($db->query("SELECT id FROM deposits WHERE status=?i",1));
				$query = $db->query("SELECT COUNT(id) as allusers FROM `ss_users` WHERE 1");	
				$qqq=$db->fetch($query);
				$allusers=$qqq['allusers'];
				$time_today=time()-86400;
				$query = $db->query("SELECT COUNT(id) as userstoday FROM `ss_users` WHERE `reg_unix`>?i",$time_today);	
				$qqq=$db->fetch($query);
				$users_today=$qqq['userstoday'];				
                $AmountDeposits=$db->getOne("SELECT sum(summa) FROM `pay` WHERE type='Оплата мощности автомобиля'");
				$query = $db->query("SELECT SUM(summa) as summawthd FROM `deposits` WHERE status=1");	
				$qqq=$db->fetch($query);
				$allout=$qqq['summawthd'];
				$allout2=$allout+($allout*($percent_u/100));
				$allout2 = number_format($allout2, 2, '.', '');
				$query = $db->query("SELECT SUM(refill) as summawthd FROM `ss_users` WHERE act_1=0");	
				$qqq=$db->fetch($query);
				$allin=$qqq['summawthd'];
				$query = $db->query("SELECT SUM(refill) as summawthd FROM `ss_users` WHERE id=?i",$id);	
				$qqq=$db->fetch($query);
				$allinuser=$qqq['summawthd'];
				$query = $db->query("SELECT SUM(ref_pay) as summawthd FROM `ss_users` WHERE act_1=0");	
				$qqq=$db->fetch($query);
				$allref=$qqq['summawthd'];
				$reserv=$allin-$allout-$allref;
				//-----user online-----
$base = "base_sessions.dat"; //файл, в котором храним идентификаторы и время
$LastTime = time() - 300; //через какое время сессии удаляются (время в секундах)
touch($base);
$file = file($base);
$idses = session_id(); //выделяем уникальный идентификатор сессии
if ($idses!='') {
  $ResFile = array();
  foreach($file as $line) {
    list($sid, $utime) = explode('|', $line);
    if ($utime > $LastTime) {
      $ResFile[$sid] = trim($sid).'|'.trim($utime).PHP_EOL;
    }
  }
  $ResFile[$idses] = trim($idses).'|'.time().PHP_EOL;
  file_put_contents($base, $ResFile, LOCK_EX);
  $file=$ResFile;
}
?>
<?if(empty($id)){?>
<div class="dm-overlay" id="reg-in">
    <div class="dm-table">
        <div class="dm-cell">
            <div class="dm-modal">
                <a href="#close" class="close"></a>
                <h4 style="color: #000;font-weight: 400;font-size: 18px;padding-left: 5px;line-height: 30px;">Регистрация / Авторизация</h4>
                <div class="pl-left">
                 <style>
.tooltip {
      position: fixed;
      padding: 10px 20px;
      border: 1px solid #b3c9ce;
      border-radius: 4px;
      text-align: center;
      font: 14px/1.3 arial, sans-serif;
      color: #333;
      background: #fff;
      box-shadow: 3px 3px 3px rgba(0, 0, 0, .3);
    }
  </style>
  <script>
	
    function reg(){
	wallet=$('#wallet').val();
	p1=/^P[0-9]+$/;
	p2=/^41001[0-9]+$/;
	if(wallet.search(p1)==-1 && wallet.search(p2)==-1){
	$('#message').fadeIn();
    return false;
    }
	$('#formreg').submit();
	}


  </script>
<center>
<form action="" method="post" id="formreg">	
<input type="hidden" name="do" value="toaccount">
<input type="hidden" name="antipovtor" value="<?=time();?>">
<table height="21px" border="0">
<tbody>
<tr>
<td align="center" style="text-align: center;border-bottom: 1px solid #ffffff00;">
<input autocomplete="off" onclick="$('#message').fadeOut();" title="Например: P12345678" name="wallet" type="text" size="23" maxlength="35" placeholder="Введите кошелек PAYEER" class="button -green_border -login -login_white" style="text-transform: none;width: 100%;height: 54px;padding-left: 10px;padding-right: 10px;color: #4c5053;margin-top: 20px;margin-bottom: 10px;border: 2px solid #e6e6e6;outline: 0 !important;text-align: center;">
<input autocomplete="off" name="captcha" type="text" size="23" maxlength="35" placeholder="Введите капчу" class="button -green_border -login -login_white" style="text-transform: none;width: 100%;height: 54px;background: rgba(255, 255, 255, 0) url(/secpic.php?r=<?=time()?>) no-repeat;background-size: 75px;padding-left: 10px;padding-right: 10px;border-left-width: 3px;margin-bottom: 15px;color: #4c5053;border: 2px solid #e6e6e6;outline: 0 !important;text-align: center;">
<input type="submit" name="submit" id="form" value="Продолжить" class="buy-car" style="border: none;outline: 0 !important;margin: 0 auto;width: 100%;" placeholder="">
<div style="overflow: hidden;width: 100%;padding-top: 20px;">
<h1 style="font-size: 13px;margin: 0;font-weight: 500;font-family: 'Rubik', sans-serif;text-align: center;padding: 1px;color: #252b2d;line-height: 22px;">У вас нет кошелька <font style="color: #3e85c1;">PAY</font>EER WALLET? <a href="https://payeer.com" style="text-decoration: none;color: #000; border-bottom: 1px dashed #000;" target="_blank"> Зарегистрируйте!</a></h1>
</div>
</td>
</tr>
</tbody>
</table>
</form>
</center>		 
				  
</div>
</div>
</div>
</div>
</div>

<?php if($_SERVER['REQUEST_URI']=='/' && $_SERVER['REQUEST_URI']!='/index' or $_GET['ref']!='') {  ?>
<div class="lake">
<div class="line-background">
<div class="line s1"></div>
<div class="line s2"></div>
<div class="line s3"></div>
<div class="line s4"></div>
<div class="line s5"></div>
<div class="line s6"></div>
<div class="line s7"></div>
<div class="line s8"></div>
<div class="line s9"></div>
</div>
<div class="lake-menu">
<a href="/" style="background: linear-gradient(135deg, #fcc12f 0%, #fdac0f 100%);border-radius: 50%;border: 8px solid #20201f;color: #2c2d31 !important;position: absolute;width: 70px;height: 70px;margin-left: 40px;margin-top: 0px;">
<img class="" style="width: 140px;position: absolute;margin-left: -58px;margin-top: -20px;" src="/images/logo.svg">
<font style="text-align: center;width: 200px;position: absolute;font-weight: 900;font-size: 24px;color: #fff;margin-left: -83px;line-height: 22px;text-shadow: 1px 2px #f58f16, 1px 1px rgba(200, 120, 22, .2);font-family: 'Rubik', sans-serif;text-transform: uppercase;margin-top: -5px;-moz-transform: rotate(-15deg); /* Для Firefox */-ms-transform: rotate(-15deg); /* Для IE */-webkit-transform: rotate(-15deg); /* Для Safari, Chrome, iOS */-o-transform: rotate(-15deg); /* Для Opera */transform: rotate(-15deg);">Speed Car<br>Online</font>
</a>
<div style="width: 700px;float:right;margin-top: 10px;text-align: right;">
 <a href="/"> Главная</a>
	<a href="/about">О проекте</a>
	<a href="/faq">F.A.Q</a>
	<a href="/rules">Правила</a>
	<a href="/contacts">Контакты</a>
	<a href="https://vk.com/speedcar_online" target="_blank" style=""><i class="fa fa-vk"></i></a>
	</div>
	</div>
<div class="ctn">
 <div class="chains-our-car hidden-xs hidden-sm">
     <span class="number-1">+ 10 RUB</span>
     <span class="number-2">+ 200 RUB</span>
     <span class="number-3">+ 70 RUB</span>
     <span class="number-4">+ 130 RUB</span>
 </div>
<h1 style="color: #fff;font-weight: 800;font-family: 'Rubik', sans-serif;font-size: 70px;letter-spacing: 0.5;text-align: center;">SPEED CAR ONLINE</h1>
<p style="color: #fff;letter-spacing: 0.5;text-align: center;padding-top: 0px;font-size: 17px;padding-bottom: 0px;font-weight: 300;">Прокачивайте мощность своего автомобиля и зарабатывайте</p>
<div class="text-center">
      <img class="" style="max-width:100%;" src="/images/huracan-1.png">
    </div>

<div class="row text-center" style="padding-top: 20px;">
<div class="col-md-3">
<div class="block-slider-info">Резерв проекта
<br><h4 style="margin-bottom:0;"><?=number_format($AmountDeposits, 2, '.', ' ');?> RUB</h4>
</div>
</div>

<div class="col-md-3">
<div class="block-slider-info">Всего водителей
<br><h4 style="margin-bottom:0;"><?=$allusers?> ЧЕЛ<span></span></h4>
</div>
</div>

<div class="col-md-3">
<div class="block-slider-info">Сейчас в онлайне
<br><h4 style="margin-bottom:0;"><?=$online?> ЧЕЛ<span></span></h4>
</div>
</div>

<div class="col-md-3">
<div style="position:relative;top:10px;">
<a class="buy-car" href="#reg-in" style="padding: 0 30px;padding-left: 50px;">
<svg width="20px" height="20px" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="width: 15px;position: absolute;margin-left: -20px;margin-top: 14px;">
                  <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                        <g id="Dribbble-Dark-Preview" transform="translate(-140.000000, -2159.000000)" fill="#000">
                                            <g id="icons" transform="translate(56.000000, 160.000000)">
                                                <path d="M100.562548,2016.99998 L87.4381713,2016.99998 C86.7317804,2016.99998 86.2101535,2016.30298 86.4765813,2015.66198 C87.7127655,2012.69798 90.6169306,2010.99998 93.9998492,2010.99998 C97.3837885,2010.99998 100.287954,2012.69798 101.524138,2015.66198 C101.790566,2016.30298 101.268939,2016.99998 100.562548,2016.99998 M89.9166645,2004.99998 C89.9166645,2002.79398 91.7489936,2000.99998 93.9998492,2000.99998 C96.2517256,2000.99998 98.0830339,2002.79398 98.0830339,2004.99998 C98.0830339,2007.20598 96.2517256,2008.99998 93.9998492,2008.99998 C91.7489936,2008.99998 89.9166645,2007.20598 89.9166645,2004.99998 M103.955674,2016.63598 C103.213556,2013.27698 100.892265,2010.79798 97.837022,2009.67298 C99.4560048,2008.39598 100.400241,2006.33098 100.053171,2004.06998 C99.6509769,2001.44698 97.4235996,1999.34798 94.7348224,1999.04198 C91.0232075,1998.61898 87.8750721,2001.44898 87.8750721,2004.99998 C87.8750721,2006.88998 88.7692896,2008.57398 90.1636971,2009.67298 C87.1074334,2010.79798 84.7871636,2013.27698 84.044024,2016.63598 C83.7745338,2017.85698 84.7789973,2018.99998 86.0539717,2018.99998 L101.945727,2018.99998 C103.221722,2018.99998 104.226185,2017.85698 103.955674,2016.63598" id="profile_round-[#1342]"></path>
                                            </g>
                                        </g>
                                    </g>
                                </svg>
Присоединиться
</a>
</div> 
</div>

</div>

</div>	
	 
 
</div>
<? } else { ?>
<div class="all-page-yellow"></div>
<div id="particles-js"><canvas class="particles-js-canvas-el" width="1349" height="342" style="width: 100%; height: 100%;"></canvas></div>
<div class="one-scroll no-home">
<div class="lake-menu">
<a href="/" style="background: linear-gradient(135deg, #fcc12f 0%, #fdac0f 100%);border-radius: 50%;border: 8px solid #20201f;color: #2c2d31 !important;position: absolute;width: 70px;height: 70px;margin-left: 40px;margin-top: 0px;">
<img class="" style="width: 140px;position: absolute;margin-left: -58px;margin-top: -20px;" src="/images/logo.svg">
<font style="text-align: center;width: 200px;position: absolute;font-weight: 900;font-size: 24px;color: #fff;margin-left: -83px;line-height: 22px;text-shadow: 1px 2px #f58f16, 1px 1px rgba(200, 120, 22, .2);font-family: 'Rubik', sans-serif;text-transform: uppercase;margin-top: -5px;-moz-transform: rotate(-15deg); /* Для Firefox */-ms-transform: rotate(-15deg); /* Для IE */-webkit-transform: rotate(-15deg); /* Для Safari, Chrome, iOS */-o-transform: rotate(-15deg); /* Для Opera */transform: rotate(-15deg);">Speed Car<br>Online</font>
</a>
<div style="width: 800px;float:right;margin-top: 10px;text-align: right;">
 <a href="/"> Главная</a>
	<a href="/about">О проекте</a>
	<a href="/faq">F.A.Q</a>
	<a href="/rules">Правила</a>
	<a href="/contacts">Контакты</a>
		<a href="#reg-in" style="padding-right: 15px;border: 2px solid #fbc130;border-radius: 25px;color: #fbc130;margin-left: 10px;margin-right: 10px;font-weight: 500;padding-left: 40px;">
	<svg width="20px" height="20px" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="width: 15px;position: absolute;margin-left: -22px;margin-top: -0px;">
                  <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" style="">
                                        <g id="Dribbble-Dark-Preview" transform="translate(-140.000000, -2159.000000)" fill="#fbc130">
                                            <g id="icons" transform="translate(56.000000, 160.000000)">
                                                <path d="M100.562548,2016.99998 L87.4381713,2016.99998 C86.7317804,2016.99998 86.2101535,2016.30298 86.4765813,2015.66198 C87.7127655,2012.69798 90.6169306,2010.99998 93.9998492,2010.99998 C97.3837885,2010.99998 100.287954,2012.69798 101.524138,2015.66198 C101.790566,2016.30298 101.268939,2016.99998 100.562548,2016.99998 M89.9166645,2004.99998 C89.9166645,2002.79398 91.7489936,2000.99998 93.9998492,2000.99998 C96.2517256,2000.99998 98.0830339,2002.79398 98.0830339,2004.99998 C98.0830339,2007.20598 96.2517256,2008.99998 93.9998492,2008.99998 C91.7489936,2008.99998 89.9166645,2007.20598 89.9166645,2004.99998 M103.955674,2016.63598 C103.213556,2013.27698 100.892265,2010.79798 97.837022,2009.67298 C99.4560048,2008.39598 100.400241,2006.33098 100.053171,2004.06998 C99.6509769,2001.44698 97.4235996,1999.34798 94.7348224,1999.04198 C91.0232075,1998.61898 87.8750721,2001.44898 87.8750721,2004.99998 C87.8750721,2006.88998 88.7692896,2008.57398 90.1636971,2009.67298 C87.1074334,2010.79798 84.7871636,2013.27698 84.044024,2016.63598 C83.7745338,2017.85698 84.7789973,2018.99998 86.0539717,2018.99998 L101.945727,2018.99998 C103.221722,2018.99998 104.226185,2017.85698 103.955674,2016.63598" id="profile_round-[#1342]"></path>
                                            </g>
                                        </g>
                                    </g>
                                </svg>
	Присоединиться</a>
	<a href="https://vk.com/speedcar_online" target="_blank" style=""><i class="fa fa-vk"></i></a>
	</div>
<div class="page-header-title" style="position: absolute;margin-left: 469px;width: 700px;text-align: right;margin-top: 50px;padding-right: 10px;">
        <h4 class="page-title" style="font-size: 14px;font-weight: 300;letter-spacing: 0.5px;">Speed Car Online "Прокачай свою тачку" / <b style="font-weight:400;">{!TITLE!}</b></h4>
    </div>    
	</div>


</div>
<?PHP } ?> 


<?}else{?>

<?
if(!empty($id)){
$wallet=$db->getOne("SELECT wallet FROM ss_users WHERE id=?i",$id);
?>
<script type="text/javascript">
function number_format( number, decimals, dec_point, thousands_sep ) {	// Format a number with grouped thousands
	var i, j, kw, kd, km;

	if( isNaN(decimals = Math.abs(decimals)) ){
		decimals = 2;
	}
	if( dec_point == undefined ){
		dec_point = ".";
	}
	if( thousands_sep == undefined ){
		thousands_sep = " ";
	}
	i = parseInt(number = (+number || 0).toFixed(decimals)) + "";

	if( (j = i.length) > 3 ){
		j = j % 3;
	} else{
		j = 0;
	}

	km = (j ? i.substr(0, j) + thousands_sep : "");
	kw = i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousands_sep);
	//kd = (decimals ? dec_point + Math.abs(number - i).toFixed(decimals).slice(2) : "");
	kd = (decimals ? dec_point + Math.abs(number - i).toFixed(decimals).replace(/-/, 0).slice(2) : "");


	return km + kw + kd;
}


var cf=<?php echo $cf; ?>;
function generateThis() {
	var sum=document.getElementById("getsum").value;
	var mn=sum*cf;
	$("#dmn").html(number_format(mn*86400*30));
}



</script>
<div class="dm-overlay" id="oplata-in">
    <div class="dm-table">
        <div class="dm-cell">
            <div class="dm-modal">
                <a href="#close" class="close"></a>
                <h4 style="color: #000;font-weight: 400;font-size: 18px;padding-left: 5px;line-height: 30px;">Оплата мощности автомобиля</h4>
                <div class="pl-left">
                 <style>
.tooltip {
      position: fixed;
      padding: 10px 20px;
      border: 1px solid #b3c9ce;
      border-radius: 4px;
      text-align: center;
      font: 14px/1.3 arial, sans-serif;
      color: #333;
      background: #fff;
      box-shadow: 3px 3px 3px rgba(0, 0, 0, .3);
    }
  </style>

<center>
<form action="" method="post" id="oplata">	
<input type="hidden" name="do" value="payeer_pay">
<input type="hidden" name="antipovtor" value="<?=time();?>">
<table height="21px" border="0">
<tbody>
<tr>
<td align="center" style="text-align: center;border-bottom: 1px solid #ffffff00;">
<input autocomplete="off" type="text" name="m_amount" id="getsum" placeholder="Сумма от 15 до 10000 RUB" onkeyup="generateThis();" type="text" size="23" maxlength="35" class="button -green_border -login -login_white" style="text-transform: none;width: 100%;height: 54px;padding-left: 10px;padding-right: 10px;color: #000000;margin-top: 20px;margin-bottom: 10px;border: 2px solid #e6e6e6;outline: 0 !important;text-align: center;min-width: 450px;">
<div style="overflow: hidden;width: 100%;padding-top: 5px;padding-bottom: 10px;">
<h1 style="font-size: 13px;margin: 0;font-weight: 500;font-family: 'Rubik', sans-serif;text-align: center;padding: 1px;color: #252b2d;line-height: 22px;">Доход в месяц составит: <font id="dmn" style="color: #d29a0d;">PAY</font> RUB</h1>
</div>

<script>
var cf2=<?php echo $cf; ?>;

	var sum=document.getElementById("getsum").value;
	var mn=sum*cf2;
	$("#dmn").html(number_format(mn*86400*30));
</script>
<input type="submit" name="submit" id="form" value="Оплатить мощность" class="buy-car" style="border: none;outline: 0 !important;margin: 0 auto;width: 100%;" placeholder="">
</td>
</tr>
</tbody>
</table>
</form>
</center>		 
				  
</div>
</div>
</div>
</div>
</div>

<?php if($_SERVER['REQUEST_URI']=='/' && $_SERVER['REQUEST_URI']!='/index' or $_GET['ref']!='') {  ?>

<div class="lake">
<div class="line-background">
<div class="line s1"></div>
<div class="line s2"></div>
<div class="line s3"></div>
<div class="line s4"></div>
<div class="line s5"></div>
<div class="line s6"></div>
<div class="line s7"></div>
<div class="line s8"></div>
<div class="line s9"></div>
</div>
<div class="lake-menu">
<a href="/" style="background: linear-gradient(135deg, #fcc12f 0%, #fdac0f 100%);border-radius: 50%;border: 8px solid #20201f;color: #2c2d31 !important;position: absolute;width: 70px;height: 70px;margin-left: 40px;margin-top: 0px;">
<img class="" style="width: 140px;position: absolute;margin-left: -58px;margin-top: -20px;" src="/images/logo.svg">
<font style="text-align: center;width: 200px;position: absolute;font-weight: 900;font-size: 24px;color: #fff;margin-left: -83px;line-height: 22px;text-shadow: 1px 2px #f58f16, 1px 1px rgba(200, 120, 22, .2);font-family: 'Rubik', sans-serif;text-transform: uppercase;margin-top: -5px;-moz-transform: rotate(-15deg); /* Для Firefox */-ms-transform: rotate(-15deg); /* Для IE */-webkit-transform: rotate(-15deg); /* Для Safari, Chrome, iOS */-o-transform: rotate(-15deg); /* Для Opera */transform: rotate(-15deg);">Speed Car<br>Online</font>
</a>
<div style="width: 700px;float:right;margin-top: 10px;text-align: right;">
 <a href="/"> Главная</a>
	<a href="/about">О проекте</a>
	<a href="/faq">F.A.Q</a>
	<a href="/rules">Правила</a>
	<a href="/contacts">Контакты</a>
	<a href="https://vk.com/speedcar_online" target="_blank" style=""><i class="fa fa-vk"></i></a>
	</div>
	</div>
<div class="ctn">
 <div class="chains-our-car hidden-xs hidden-sm">
     <span class="number-1">+ 10 RUB</span>
     <span class="number-2">+ 200 RUB</span>
     <span class="number-3">+ 70 RUB</span>
     <span class="number-4">+ 130 RUB</span>
 </div>
<h1 style="color: #fff;font-weight: 800;font-family: 'Rubik', sans-serif;font-size: 70px;letter-spacing: 0.5;text-align: center;">SPEED CAR ONLINE</h1>
<p style="color: #fff;letter-spacing: 0.5;text-align: center;padding-top: 0px;font-size: 17px;padding-bottom: 0px;font-weight: 300;">Прокачивайте мощность своего автомобиля и зарабатывайте</p>
<div class="text-center">
      <img class="" style="max-width:100%;" src="/images/huracan-1.png">
    </div>

<div class="row text-center" style="padding-top: 20px;">
<div class="col-md-3">
<div class="block-slider-info">Резерв проекта
<br><h4 style="margin-bottom:0;"><?=number_format($AmountDeposits, 2, '.', ' ');?> RUB</h4>
</div>
</div>

<div class="col-md-3">
<div class="block-slider-info">Всего водителей
<br><h4 style="margin-bottom:0;"><?=$allusers?> ЧЕЛ<span></span></h4>
</div>
</div>

<div class="col-md-3">
<div class="block-slider-info">Сейчас в онлайне
<br><h4 style="margin-bottom:0;"><?=$online?> ЧЕЛ<span></span></h4>
</div>
</div>

<div class="col-md-3">
<div style="position:relative;top:10px;">
<a class="buy-car" href="/my" style="padding: 0 30px;padding-left: 50px;">
<svg width="20px" height="20px" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="width: 15px;position: absolute;margin-left: -20px;margin-top: 14px;">
                  <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                        <g id="Dribbble-Dark-Preview" transform="translate(-140.000000, -2159.000000)" fill="#000">
                                            <g id="icons" transform="translate(56.000000, 160.000000)">
                                                <path d="M100.562548,2016.99998 L87.4381713,2016.99998 C86.7317804,2016.99998 86.2101535,2016.30298 86.4765813,2015.66198 C87.7127655,2012.69798 90.6169306,2010.99998 93.9998492,2010.99998 C97.3837885,2010.99998 100.287954,2012.69798 101.524138,2015.66198 C101.790566,2016.30298 101.268939,2016.99998 100.562548,2016.99998 M89.9166645,2004.99998 C89.9166645,2002.79398 91.7489936,2000.99998 93.9998492,2000.99998 C96.2517256,2000.99998 98.0830339,2002.79398 98.0830339,2004.99998 C98.0830339,2007.20598 96.2517256,2008.99998 93.9998492,2008.99998 C91.7489936,2008.99998 89.9166645,2007.20598 89.9166645,2004.99998 M103.955674,2016.63598 C103.213556,2013.27698 100.892265,2010.79798 97.837022,2009.67298 C99.4560048,2008.39598 100.400241,2006.33098 100.053171,2004.06998 C99.6509769,2001.44698 97.4235996,1999.34798 94.7348224,1999.04198 C91.0232075,1998.61898 87.8750721,2001.44898 87.8750721,2004.99998 C87.8750721,2006.88998 88.7692896,2008.57398 90.1636971,2009.67298 C87.1074334,2010.79798 84.7871636,2013.27698 84.044024,2016.63598 C83.7745338,2017.85698 84.7789973,2018.99998 86.0539717,2018.99998 L101.945727,2018.99998 C103.221722,2018.99998 104.226185,2017.85698 103.955674,2016.63598" id="profile_round-[#1342]"></path>
                                            </g>
                                        </g>
                                    </g>
                                </svg>
Вернуться в аккаунт
</a>
</div> 
</div>

</div>

</div>	
	 
 
</div>


<?}else{?>


<?
$ihr=$db->getOne("SELECT i_have_refs_as_curator FROM ss_users WHERE id=?i",$id);
?>
<div class="all-page-yellow"></div>
<div id="particles-js"><canvas class="particles-js-canvas-el" width="1349" height="342" style="width: 100%; height: 100%;"></canvas></div>
<div class="one-scroll no-home">
<div class="lake-menu">
<a href="/" style="background: linear-gradient(135deg, #fcc12f 0%, #fdac0f 100%);border-radius: 50%;border: 8px solid #20201f;color: #2c2d31 !important;position: absolute;width: 70px;height: 70px;margin-left: 40px;margin-top: 0px;">
<img class="" style="width: 140px;position: absolute;margin-left: -58px;margin-top: -20px;" src="/images/logo.svg">
<font style="text-align: center;width: 200px;position: absolute;font-weight: 900;font-size: 24px;color: #fff;margin-left: -83px;line-height: 22px;text-shadow: 1px 2px #f58f16, 1px 1px rgba(200, 120, 22, .2);font-family: 'Rubik', sans-serif;text-transform: uppercase;margin-top: -5px;-moz-transform: rotate(-15deg); /* Для Firefox */-ms-transform: rotate(-15deg); /* Для IE */-webkit-transform: rotate(-15deg); /* Для Safari, Chrome, iOS */-o-transform: rotate(-15deg); /* Для Opera */transform: rotate(-15deg);">Speed Car<br>Online</font>
</a>
<div style="width: 800px;float:right;margin-top: 10px;text-align: right;">
 <a href="/"> Главная</a>
	<a href="/about">О проекте</a>
	<a href="/faq">F.A.Q</a>
	<a href="/rules">Правила</a>
	<a href="/contacts">Контакты</a>
	<a href="/my" style="padding-right: 15px;border: 2px solid #fbc130;border-radius: 25px;color: #fbc130;margin-left: 10px;margin-right: 10px;font-weight: 500;padding-left: 40px;">
	<svg width="20px" height="20px" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="width: 15px;position: absolute;margin-left: -22px;margin-top: -0px;">
                  <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" style="">
                                        <g id="Dribbble-Dark-Preview" transform="translate(-140.000000, -2159.000000)" fill="#fbc130">
                                            <g id="icons" transform="translate(56.000000, 160.000000)">
                                                <path d="M100.562548,2016.99998 L87.4381713,2016.99998 C86.7317804,2016.99998 86.2101535,2016.30298 86.4765813,2015.66198 C87.7127655,2012.69798 90.6169306,2010.99998 93.9998492,2010.99998 C97.3837885,2010.99998 100.287954,2012.69798 101.524138,2015.66198 C101.790566,2016.30298 101.268939,2016.99998 100.562548,2016.99998 M89.9166645,2004.99998 C89.9166645,2002.79398 91.7489936,2000.99998 93.9998492,2000.99998 C96.2517256,2000.99998 98.0830339,2002.79398 98.0830339,2004.99998 C98.0830339,2007.20598 96.2517256,2008.99998 93.9998492,2008.99998 C91.7489936,2008.99998 89.9166645,2007.20598 89.9166645,2004.99998 M103.955674,2016.63598 C103.213556,2013.27698 100.892265,2010.79798 97.837022,2009.67298 C99.4560048,2008.39598 100.400241,2006.33098 100.053171,2004.06998 C99.6509769,2001.44698 97.4235996,1999.34798 94.7348224,1999.04198 C91.0232075,1998.61898 87.8750721,2001.44898 87.8750721,2004.99998 C87.8750721,2006.88998 88.7692896,2008.57398 90.1636971,2009.67298 C87.1074334,2010.79798 84.7871636,2013.27698 84.044024,2016.63598 C83.7745338,2017.85698 84.7789973,2018.99998 86.0539717,2018.99998 L101.945727,2018.99998 C103.221722,2018.99998 104.226185,2017.85698 103.955674,2016.63598" id="profile_round-[#1342]"></path>
                                            </g>
                                        </g>
                                    </g>
                                </svg>
	Вернуться в аккаунт</a>
	<a href="https://vk.com/speedcar_online" target="_blank" style=""><i class="fa fa-vk"></i></a>
	</div>
<div class="page-header-title" style="position: absolute;margin-left: 469px;width: 700px;text-align: right;margin-top: 50px;padding-right: 10px;">
        <h4 class="page-title" style="font-size: 14px;font-weight: 300;letter-spacing: 0.5px;">Speed Car Online "Прокачай свою тачку" / <b style="font-weight:400;">{!TITLE!}</b></h4>
    </div>    
	</div>


</div>


<?}?>
<?}?>
<?}?>
