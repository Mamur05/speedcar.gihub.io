<?
if(!defined('SKYLIGHT')){
exit();
}
?>

  

<br><br>
<div class="footer-lake">
<div style="width: 1170px;margin:0 auto;color:#fff;text-align: center;padding: 30px 30px;padding-top: 150px;font-weight: 400;font-size: 15px;">
<a href="#" style="background: linear-gradient(135deg, #fcc12f 0%, #fdac0f 100%);border-radius: 50%;border: 8px solid #20201f;color: #2c2d31 !important;position: absolute;width: 70px;height: 70px;margin-left: 245px;margin-top: -100px;">
<img class="" style="width: 140px;position: absolute;margin-left: -58px;margin-top: -20px;" src="/images/logo.svg">
<font style="text-align: center;width: 200px;position: absolute;font-weight: 900;font-size: 24px;color: #fff;margin-left: -101px;line-height: 22px;text-shadow: 1px 2px #f58f16, 1px 1px rgba(200, 120, 22, .2);font-family: 'Rubik', sans-serif;text-transform: uppercase;margin-top: 5px;-moz-transform: rotate(-15deg); /* Для Firefox */-ms-transform: rotate(-15deg); /* Для IE */-webkit-transform: rotate(-15deg); /* Для Safari, Chrome, iOS */-o-transform: rotate(-15deg); /* Для Opera */transform: rotate(-15deg);">Speed Car<br>Online</font>
</a>
Все права защищены! 2018 © SPEED CAR ONLINE - Прокачай свою тачку
</div>
</div>
<script src="/js/particles.js"></script>
<script type="text/javascript" src="/js/theme.js"></script>
</body></html>